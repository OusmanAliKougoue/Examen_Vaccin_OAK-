#include "Vaccin.h"

Vaccin::Vaccin(string& nm,double volume,int nbdose,Fabrication mode)
{
    cout<<"\nAppel du constructeur pour la classe Vaccin d'adresse :"<<this<<endl;
    nom=nm;
    volume_dose=volume;
    nb_doses=nbdose;
    mode_fabrication=mode;

}
    void Vaccin::afficher(){
        cout<<nom<<endl;
        cout<<"Volume/dose :"<<volume_dose<<endl;
        cout<<"nombre de doses :"<<nb_doses<<endl;
        cout<<"mode de fabrication "<<mode_fabrication<<endl;

    }
     double Vaccin::conditionnement(){
        return volume_dose*nb_doses*COND_UNITE;
     }
     double Vaccin::fabrication(){
        double cout=volume_dose*nb_doses*PRIX_BASE;
        if(mode_fabrication==Standard){
        return cout;
        }
        else 
        {
            return cout+(cout*MAJORATION_HIGHTECH);

        }

     }
     double  Vaccin::production(){
        return (conditionnement()+fabrication());
     }