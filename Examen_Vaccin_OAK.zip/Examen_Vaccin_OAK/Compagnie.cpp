#include "Compagnie.h"
Compagnie::Compagnie(string& nm)
{
    cout<<"\nAppel du constructeur pour la classe compagnie d'adresse :"<<this<<endl;
    nom=nm;
    pharmacie=new Vaccin*[10];
    nb=0;
}
Compagnie::~Compagnie()
{
    if(pharmacie){
        for(int i=0; i< nb; i++){
            delete []pharmacie[i];
        }
        delete [] pharmacie;
    }
}
void Compagnie::ajouter(Vaccin* b){
    if(nb<10){
        pharmacie[nb++]=b;
    }
    else{
        cout<<"la compagnie est pleine"<<endl;
    }
}
double Compagnie::calcul_cout(){
    double cout=0;
    for(int i=0; i< nb; i++){
       cout+=pharmacie[i]->production();    
    }
    return cout;
}
void Compagnie::affichage(){
    cout<<"\nMa Compagnie s'appelle :"<<nom<<endl;
     for(int i=0; i< nb; i++){
        pharmacie[i]->afficher();
          
    }
}