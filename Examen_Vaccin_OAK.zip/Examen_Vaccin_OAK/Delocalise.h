#ifndef DELOCALISE_H
#define DELOCALISE_H
#include "Vaccin.h"
#include <iostream>
#include <string>
using namespace std;
class Delocalise:public Vaccin
{
private:
    bool deloca;
public:
    Delocalise(string& nm,double volume,int nbdose,Fabrication mode,bool );
    double production();
    void afficher();

};
#endif