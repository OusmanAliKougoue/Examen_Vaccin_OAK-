#include "Vaccin.h"
#include "Delocalise.h"
#include "Compagnie.h"
#include <iostream>
#include <string>
using namespace std;
int main()
{
    cout<<"------------------------VACCIN-----------------"<<endl;
    string nom1="Zamiflu";
    Vaccin v1(nom1,0.55,200000,HighTech);

    string nom2="Triphas";
    Vaccin v2(nom1,0.20,10000,Standard);

    v1.afficher();
    cout<<endl;
    v2.afficher();

    cout<<"le cout de conditioonement est de :"<<v1.conditionnement()<<endl;
    cout<<endl;
    cout<<"le cout de fabrication est de :"<<v1.fabrication()<<endl;
    cout<<endl;
     cout<<"le cout de production est de :"<<v1.production()<<endl;
     cout<<"------------------------VACCIN DELOCAL-----------------"<<endl;
      string nom3="ContreEvola";
     Delocalise v3(nom3,0.40,80000,HighTech,false);

    string nom4="ContreMpox";
    Delocalise v4(nom4,0.11,50000,Standard,true);

    v3.afficher();
    cout<<"le cout de production d'un vaccin v3 delocalise est de :"<<v3.production()<<endl;
    cout<<endl;
    v4.afficher();
    cout<<"le cout de production d'un vaccin v4 delocalise est de :"<<v4.production()<<endl;
    cout<<"------------------------COMPAGNIE PHARCE..-----------------"<<endl;
    string n="ICIBA";
    Compagnie C(n);
    C.ajouter(&v1);
    C.ajouter(&v2);
    C.ajouter(&v3);
    C.ajouter(&v4);
    C.affichage();
    cout<<"le cout de production :"<<C.calcul_cout()<<endl;  
    return 0;
}
