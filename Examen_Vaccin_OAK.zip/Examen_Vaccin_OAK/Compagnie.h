#ifndef COMPAGNIE_H
#define COMPAGNIE_H
#include "Vaccin.h"
#include <iostream>
#include <string>
using namespace std;
class Compagnie
{
private:
    string nom;
    Vaccin** pharmacie;
    int nb;
public:
    Compagnie(string& );
    ~Compagnie();
    void ajouter(Vaccin* );
    void affichage();
    double calcul_cout();
};
#endif