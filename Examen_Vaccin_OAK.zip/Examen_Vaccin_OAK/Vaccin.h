#ifndef VACCIN_H
#define VACCIN_H
#include <iostream>
#include <string>
using namespace std;

const double COND_UNITE=0.5;

const double PRIX_BASE=1.5;

const double MAJORATION_HIGHTECH=0.5;

const double REDUCTION_DELOC=0.2;

enum Fabrication{Standard,HighTech};
class Vaccin
{
private:
    string nom;
    double volume_dose;
    int nb_doses;
    Fabrication mode_fabrication;
public:
    Vaccin(string& nm,double volume,int nbdose,Fabrication mode=Standard);
      double conditionnement();
     double fabrication();
     virtual double production();
     virtual void afficher();
};
#endif