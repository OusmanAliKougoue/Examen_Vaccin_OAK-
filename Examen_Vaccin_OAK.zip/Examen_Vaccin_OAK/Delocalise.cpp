#include "Delocalise.h"
Delocalise::Delocalise(string& nm,double volume,int nbdose,Fabrication mode,bool b):Vaccin(nm,volume,nbdose,mode)
{
    cout<<"\nAppel du constructeur pour la classe Delocalisee d'adresse :"<<this<<endl;
    deloca=b;
}
 
    double Delocalise::production(){
        if(deloca){
            return Vaccin::production()-(Vaccin::production()*REDUCTION_DELOC);
        }else{
            return (Vaccin::production()/2);
        }
    }
    void Delocalise::afficher(){
        Vaccin::afficher();
        cout<<"delocalisation :"<<deloca<<endl;
    }